# Program 3
- Codes for Program 3 and 2 are in the "src" directory, please look in there for code, all other submission materials are here in this directory.
- Code for program 3 gui is in folder Program3GUI in src directory which contains:
    - Main.java
    - Controller.java
    - Program3GUI.fxml
- Program 2 code in the directory named TuitionManager in src directory; to run program 2 please open and run the Prog2.class file
- JDocs folder contains the java docs.
- Test case documents are in this directory named Program3testDoc, both word and pdf versions exist here.